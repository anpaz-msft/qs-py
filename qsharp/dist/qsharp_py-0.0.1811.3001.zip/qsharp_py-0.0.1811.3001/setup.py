from distutils.core import setup

setup(name='qsharp_py',
      version='0.0.1811.3001',
      py_modules=['qsharp'],
      )